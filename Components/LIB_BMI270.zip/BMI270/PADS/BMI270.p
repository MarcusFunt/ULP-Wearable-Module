*PADS-LIBRARY-PART-TYPES-V9*

BMI270 BMI270 I ANA 7 1 0 0 0
TIMESTAMP 2026.07.04.20.18.30
"Mouser Part Number" 262-BMI270
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Bosch-Sensortec/BMI270?qs=u16ybLDytRYIj%252BjQEee88A%3D%3D
"Manufacturer_Name" BOSCH
"Manufacturer_Part_Number" BMI270
"Description" IMUs - Inertial Measurement Units Smart Ultra-Low Power Inertial Measurement Unit (IMU) for Wearable Applications
"Datasheet Link" https://www.bosch-sensortec.com/media/boschsensortec/downloads/datasheets/bst-bmi270-ds000.pdf
"Geometry.Height" 0.87mm
GATE 1 14 0
BMI270
1 0 U SDO
2 0 U ASDX
3 0 U ASCX
4 0 U INT1
5 0 U VDDIO
6 0 U GNDIO
7 0 U GND
8 0 U VDD
9 0 U INT2
10 0 U OCSB
11 0 U OSDO
12 0 U CSB
13 0 U SCX
14 0 U SDX

*END*
*REMARK* SamacSys ECAD Model
2018740/1637722/2.50/14/3/Integrated Circuit
