*PADS-LIBRARY-PART-TYPES-V9*

226276-0202 2262760202 I CON 7 1 0 0 0
TIMESTAMP 2026.07.04.20.12.59
"Mouser Part Number" 
"Mouser Price/Stock" 
"Manufacturer_Name" Molex
"Manufacturer_Part_Number" 226276-0202
"Description" VersaPower Board-to-Board Receptacle, 0.30mm Pitch, 0.60mm Height, 20 Signal Pin + 8 Power Pin + 1 Fitting Nail, 8 Reels/Carton
"Datasheet Link" https://www.molex.com/content/dam/molex/molex-dot-com/products/automated/en-us/salesdrawingpdf/226/226276/2262760202_sd.pdf?inline
"Geometry.Height" 0.65mm
GATE 1 34 0
226276-0202
1 0 U SIGNAL_1
2 0 U SIGNAL_2
3 0 U SIGNAL_3
4 0 U SIGNAL_4
5 0 U SIGNAL_5
6 0 U SIGNAL_6
7 0 U SIGNAL_7
8 0 U SIGNAL_8
9 0 U SIGNAL_9
10 0 U SIGNAL_10
11 0 U SIGNAL_11
12 0 U SIGNAL_12
13 0 U SIGNAL_13
14 0 U SIGNAL_14
15 0 U SIGNAL_15
16 0 U SIGNAL_16
17 0 U SIGNAL_17
18 0 U SIGNAL_18
19 0 U SIGNAL_19
20 0 U SIGNAL_20
21 0 U POWER_1
22 0 U POWER_2
23 0 U POWER_3
24 0 U POWER_4
25 0 U POWER_5
26 0 U POWER_6
27 0 U POWER_7
28 0 U POWER_8
29 0 U FITTING_NAIL_1
30 0 U FITTING_NAIL_2
31 0 U FITTING_NAIL_3
32 0 U FITTING_NAIL_4
33 0 U MP_1
34 0 U MP_2

*END*
*REMARK* SamacSys ECAD Model
21996514/1637722/2.50/34/4/Connector
