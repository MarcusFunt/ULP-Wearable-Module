*PADS-LIBRARY-PART-TYPES-V9*

MCP9808T-E_MC SON50P300X200X100-9N-D I ANA 7 1 0 0 0
TIMESTAMP 2026.07.04.20.20.59
"Mouser Part Number" 579-MCP9808T-E/MC
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Microchip-Technology/MCP9808T-E-MC?qs=fgHA1UgJI8D5RNtfkSCqBg%3D%3D
"Manufacturer_Name" Microchip
"Manufacturer_Part_Number" MCP9808T-E/MC
"Description" MICROCHIP - MCP9808T-E/MC - TEMP SENSOR, I2C, -20 TO 100 DEG, 8DFN
"Datasheet Link" 
"Geometry.Height" 1mm
GATE 1 9 0
MCP9808T-E_MC
1 0 U SDA
2 0 U SCL
3 0 U ALERT
4 0 U GND
9 0 U EP
8 0 U VDD
7 0 U A0
6 0 U A1
5 0 U A2

*END*
*REMARK* SamacSys ECAD Model
520721/1637722/2.50/9/3/Integrated Circuit
