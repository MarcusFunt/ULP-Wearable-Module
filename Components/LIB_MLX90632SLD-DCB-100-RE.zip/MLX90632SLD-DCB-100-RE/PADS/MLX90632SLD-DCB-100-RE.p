*PADS-LIBRARY-PART-TYPES-V9*

MLX90632SLD-DCB-100-RE MLX90632SLDDCB100RE I ANA 7 1 0 0 0
TIMESTAMP 2026.07.04.20.22.04
"Mouser Part Number" 482-90632SLDDCB100RE
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Melexis/MLX90632SLD-DCB-100-RE?qs=W%2FMpXkg%252BdQ5ec8j9SvRcaw%3D%3D
"Manufacturer_Name" Melexis
"Manufacturer_Part_Number" MLX90632SLD-DCB-100-RE
"Description" Temperature Sensor Digital, Infrared (IR) -20C ~ 85C 0.02C 5-SFN (3x3)
"Datasheet Link" https://www.melexis.com/en/documents/documentation/datasheets/datasheet-mlx90632
"Geometry.Height" 1mm
GATE 1 6 0
MLX90632SLD-DCB-100-RE
1 0 U SDA
2 0 U VDD
3 0 U GND
4 0 U SCL
5 0 U ADDR
6 0 U EP

*END*
*REMARK* SamacSys ECAD Model
12889272/1637722/2.50/6/3/Undefined or Miscellaneous
