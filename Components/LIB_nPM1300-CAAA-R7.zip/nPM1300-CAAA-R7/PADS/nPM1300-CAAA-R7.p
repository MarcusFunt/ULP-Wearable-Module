*PADS-LIBRARY-PART-TYPES-V9*

nPM1300-CAAA-R7 BGA35C44P7X5_308X238X51 I ANA 7 1 0 0 0
TIMESTAMP 2026.07.04.19.03.40
"Mouser Part Number" 949-NPM1300-CAAA-R7
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Nordic-Semiconductor/nPM1300-CAAA-R7?qs=3pZoU%2F6IRTikGv3aUL1qeg%3D%3D
"Manufacturer_Name" Nordic Semiconductor
"Manufacturer_Part_Number" nPM1300-CAAA-R7
"Description" Battery Management Power Management IC (PMIC) with unique system management features, WLCSP
"Datasheet Link" https://infocenter.nordicsemi.com/pdf/nPM1300_PS_v1.0.pdf
"Geometry.Height" 0.512mm
GATE 1 35 0
nPM1300-CAAA-R7
A1 0 U LED0
A2 0 U LED1
A3 0 U LED2
A4 0 U LSOUT1/VOUTLDO1
A5 0 U LSOUT2/VOUTLDO2
A6 0 U AVSS
A7 0 U PVSS1
B1 0 U VBUS_1
B2 0 U VBUS_2
B3 0 U CC2
B4 0 U LSIN1/VINLDO1
B5 0 U LSIN2/VINLDO2
B6 0 U VOUT1
B7 0 U SW1
C1 0 U VSYS_1
C2 0 U VSYS_2
C3 0 U VBUSOUT
C4 0 U GPIO3
C5 0 U GPIO2
C6 0 U VOUT2
C7 0 U PVDD
D1 0 U VBAT_1
D2 0 U VBAT_2
D3 0 U NTC
D4 0 U SHPHLD
D5 0 U CC1
D6 0 U GPIO0
D7 0 U SW2
E1 0 U VSET2
E2 0 U VSET1
E3 0 U SCL
E4 0 U VDDIO
E5 0 U SDA
E6 0 U GPIO1
E7 0 U PVSS2

*END*
*REMARK* SamacSys ECAD Model
18906455/1637722/2.50/35/4/Integrated Circuit
